var class_nex_text =
[
    [ "NexText", "class_nex_text.html#a38b4dd752d39bfda4ef7642b43ded91a", null ],
    [ "getText", "class_nex_text.html#a9cf417b2f25df2872492c55bdc9f5b30", null ],
    [ "setText", "class_nex_text.html#a19589b32c981436a1bbcfe407bc766e3", null ]
];