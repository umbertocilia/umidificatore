var class_nex_progress_bar =
[
    [ "NexProgressBar", "class_nex_progress_bar.html#a61f76f0c855c7839630dbc930e3401d8", null ],
    [ "getValue", "class_nex_progress_bar.html#a3e5eb13b2aa014c8f6a9e16439917bf2", null ],
    [ "setValue", "class_nex_progress_bar.html#aaa7937d364cb63151bd1e1bc4729334d", null ]
];